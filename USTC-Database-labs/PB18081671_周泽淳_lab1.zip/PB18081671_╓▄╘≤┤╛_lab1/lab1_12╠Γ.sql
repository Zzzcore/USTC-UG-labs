#create database test;
use test;

SET foreign_key_checks = 0;
drop table if exists Book;
drop table if exists Reader;
drop table if exists Borrow;
SET foreign_key_checks = 1;

create table Book (
ID char(8) primary key,
name varchar(30) not null,
author varchar(10),
price float,
status int check(status in(0, 1))
);
create table Reader (
ID char(8) primary key,
name varchar(10),
age int,
address varchar(20)
);
create table Borrow (
book_ID char(8),
Reader_ID char(8),
Borrow_Date date,
Return_Date date,
primary key(book_id,reader_id),
constraint book foreign key(book_ID) references Book(ID),
constraint Reader foreign key(Reader_ID) references Reader(ID)
);


#insert into Book (ID, name, author, price, status) values (1, 'cat', 'bob', 100, 1);
#insert into Reader (ID, name, age, address) values (1, 'zzc', 20, 'ustc');
#insert into Borrow (book_ID, Reader_ID, Borrow_Date, Return_Date) values (1, 1, '2020-1-1', '2020-1-1');

#select * from Book;
#select * from Reader;
#select * from Borrow;


