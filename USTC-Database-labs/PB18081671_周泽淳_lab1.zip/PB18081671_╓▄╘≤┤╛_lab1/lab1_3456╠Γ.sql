#3
#<1>
select id, address from reader where name = 'rose';
#<2>
select name, borrow_date 
from book a inner join borrow b on a.id = b.book_id
where exists(
	select * from reader
    where reader.name = 'rose' and reader_id = reader.id
);
#<3>
select name from reader where not exists(
	select * from borrow
    where reader.id = borrow.reader_id #and return_date is null #两种理解
);
#<4>
select name, price from book where author = 'ullman';
#<5>
select id, name 
from book a inner join borrow b on a.id = b.book_id
where exists(
	select * from reader
    where reader.name='李林' and reader_id=reader.id
)
and return_date is null;
#<6>
select name from reader 
where exists(
	select * from borrow
    where reader.id = borrow.reader_id
    group by reader.id having count(book_id) >= 3
);
#<7>
with lilin(book_id) as(
	select book_id
	from borrow where exists(
		select * from reader
        where reader.id = reader_id and reader.name = '李林')
)
select name, id from reader a where not exists(
	select * from borrow b
    where a.id = b.reader_id
    and exists(
		select * from lilin c where b.book_id = c.book_id
    )
);
#<8>
select name, id from book
where name like '%Oracle%';
#<9>
drop view if exists borrow1;
drop view if exists new_borrow;
create view borrow1(book_name, book_id, borrow_date, reader_id) as
	select name, id, borrow_date, reader_id
    from book a inner join borrow b on a.id = b.book_id;
create view new_borrow as
	select id, name, book_id, book_name, borrow_date
	from reader a inner join borrow1 b on a.id = b.reader_id;
select distinct id from new_borrow; 
select count(distinct book_id) from new_borrow; 

drop procedure if exists modify;
drop procedure if exists checkst;
drop trigger if exists after_borrow_book;
drop trigger if exists after_return_book;
#4
DELIMITER zzz
CREATE PROCEDURE modify(in ID0 char(8), in ID1 char(8)) 
BEGIN
	insert into book(id, name, author, price, status) 
	select ID1, name, author, price, status from book where id = ID0; 
	update borrow set book_id = ID1 where book_id = ID0;
	delete from book where id = ID0;
END	zzz
delimiter ;
call modify('b1', 'b100');
select name from book where id = 'b100';

#5
DELIMITER zzz
CREATE PROCEDURE checkst() 
BEGIN
	with bookcheck(diff, id) as(
		select datediff(max(return_date),max(borrow_date)) as diff, book_id
		from borrow group by book_id
	) 
	select count(id) from book a
	where exists(
		select * from bookcheck b
		where (a.id = b.id and a.status = 0 and b.diff < 0)
			or (a.id = b.id and a.status = 1 and b.diff > 0)
	);
end zzz
delimiter ;
call checkst();

#6
show triggers;
delimiter zzz
create trigger after_borrow_book after insert on borrow for each row
begin
	update book set status = 1 where id = new.book_id;
end zzz
delimiter ;
delimiter zzz
create trigger after_return_book after update on borrow for each row
begin
	update book set status = 0 
    where book.id = new.book_id and old.return_date is null and new.return_date is not null;
end zzz
delimiter ;
#例子
delete from borrow where book_id = 'b8' and reader_id ='r1';
insert into borrow values('b8', 'r1', '2021-4-20', null);
select status from book where id = 'b8';
update borrow set return_date = '2021-4-21' where book_id = 'b8';
select status from book where id = 'b8';

