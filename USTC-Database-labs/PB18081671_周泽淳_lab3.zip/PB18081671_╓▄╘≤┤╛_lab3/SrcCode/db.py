import MySQLdb
from MySQLdb._exceptions import OperationalError

def db_login(user, passwd, server_addr, dbname):
    try:
        db = MySQLdb.connect(server_addr, user, passwd, dbname, charset = "utf8")
    except OperationalError:
        db = None

    return db



#客户信息操作
#查询操作
def client_search(db, client):
    cursor = db.cursor()

    line = ("id", "name", "phone", "address","linkname","linkphone","linkemail","link")
    res = list()


    if client[1] == '*':    #查询所有元组
        cursor.execute("select * from bclient")
        res = cursor.fetchall()
        cursor.close()
        return res
    i = 1
    while i < 9:            #对每一个列的输入都做一次查询
        if client[i] == '':
            i = i + 1
            continue
        cursor.execute("select * from bclient where " + line[i-1] + " = \'" + client[i] + '\'')
        row_cnt = cursor.fetchone()
        if row_cnt and row_cnt not in res:
            res.append(row_cnt)
        i = i + 1
    cursor.close()
    return res
#添加操作
def client_add(db, client):
    cursor = db.cursor()
    if client[1]:
        try:
            cursor.execute("insert into bclient values( " +
                           '\'' + client[1] + '\'' + ','
                           '\'' + client[2] + '\'' + ','
                           '\'' + client[3] + '\'' + ','
                           '\'' + client[4] + '\'' + ','
                           '\'' + client[5] + '\'' + ','
                           '\'' + client[6] + '\'' + ','
                           '\'' + client[7] + '\'' + ','
                           '\'' + client[8] + '\'' + ')')
            db.commit()
        except:
            db.rollback()
    cursor.close()
#删除操作
def client_delete(db, client):
    cursor = db.cursor()
    try:
        cursor.execute("delete from bclient where id = " + client[1])
        db.commit()
    except:
        db.rollback()
        cursor.close()
        return "HAVE BUSINESS"
    cursor.close()
    return "OK"
#更新操作
def client_update(db, client):
    cursor = db.cursor()
    line = ("id", "name", "phone", "address", "linkname", "linkphone", "linkemail", "link")

    cursor.execute("select id from bclient where id = \'" + client[1] + '\'')
    flag = cursor.fetchone()
    if flag == None:
        cursor.close()
        return "NO ID"

    i = 2
    while i < 9:  # 对每一个列的输入都做一次更新
        if client[i] == '':
            i = i + 1
            continue
        try:
            cursor.execute("update bclient set " + line[i - 1] + " = \'" + client[i]
                           + "\' where id = \'" + client[1] +'\'')
        except:
            db.rollback()
            cursor.close()
            return "ERROR"
        i = i + 1
    db.commit()
    cursor.close()
    return "OK"



#储蓄账户信息操作
#查询操作
def saccount_search(db, saccount):
    cursor = db.cursor()

    line = ("sacid", "rate", "curtype","sbalance","id","brid")
    res = list()


    if saccount[1] == '*':    #查询所有元组
        cursor.execute("select * from saccount")
        res = cursor.fetchall()
        cursor.close()
        return res
    i = 1
    while i < 7:            #对每一个列的输入都做一次查询
        if saccount[i] == '':
            i = i + 1
            continue
        cursor.execute("select * from saccount where " + line[i-1] + " = \'" + saccount[i] + '\'')
        row_cnt = cursor.fetchone()
        if row_cnt and row_cnt not in res:
            res.append(row_cnt)
        try:
            cursor.execute("update saccount set slatestdate=current_date where "
                           + line[i - 1] + " = \'" + saccount[i] + '\'')
            db.commit()
        except:
            db.rollback()
        i = i + 1
    cursor.close()
    return res
#添加操作
def saccount_add(db, saccount):
    cursor = db.cursor()
    if saccount[1]:
        try:
            cursor.execute("insert into saccount values( " +
                           '\'' + saccount[1] + '\'' + ','
                           '\'' + saccount[2] + '\'' + ','
                           '\'' + saccount[3] + '\'' + ','
                           '\'' + saccount[4] + '\'' + ','
                           '\'' + saccount[5] + '\'' + ','                            
                           '\'' + saccount[6] + '\'' + ','                            
                           "current_date, current_date)")
            db.commit()
        except:
            db.rollback()
    cursor.close()
#删除操作
def saccount_delete(db, saccount):
    cursor = db.cursor()
    try:
        cursor.execute("SET foreign_key_checks = 0")
        cursor.execute("delete from saccount where sacid = " + saccount[1])
        cursor.execute("SET foreign_key_checks = 1")
        db.commit()
    except:
        db.rollback()
        cursor.close()
        return "ERROR"
    cursor.close()
    return "OK"
#更新操作
def saccount_update(db, saccount):
    cursor = db.cursor()
    line = ("sacid", "rate", "curtype","sbalance")
    try:
        i = 2
        while i < 5:  # 对每一个列的输入都做一次更新
            if saccount[i] == '':
                i = i + 1
                continue
            cursor.execute("update saccount set " + line[i - 1] + " = \'" + saccount[i]
                           + "\' where sacid = \'" + saccount[1] +'\'')
            i = i + 1
        cursor.execute("update saccount set slatestdate=current_date where sacid=\'"
                       + saccount[1] + '\'')
        db.commit()
    except:
        db.rollback()
    cursor.close()





#支票账户信息操作
#查询操作
def caccount_search(db, caccount):
    cursor = db.cursor()

    line = ("cacid", "overdraft", "cbalance","id","brid")
    res = list()


    if caccount[1] == '*':    #查询所有元组
        cursor.execute("select * from caccount")
        res = cursor.fetchall()
        cursor.close()
        return res
    i = 1
    while i < 6:            #对每一个列的输入都做一次查询
        if caccount[i] == '':
            i = i + 1
            continue
        cursor.execute("select * from caccount where " + line[i-1] + " = \'" + caccount[i] + '\'')
        row_cnt = cursor.fetchone()
        if row_cnt and row_cnt not in res:
            res.append(row_cnt)
        try:
            cursor.execute("update caccount set clatestdate=current_date where "
                           + line[i - 1] + " = \'" + caccount[i] + '\'')
            db.commit()
        except:
            db.rollback()
        i = i + 1
    cursor.close()
    return res
#添加操作
def caccount_add(db, caccount):
    cursor = db.cursor()
    if caccount[1]:
        try:
            cursor.execute("insert into caccount values( " +
                           '\'' + caccount[1] + '\'' + ','
                           '\'' + caccount[2] + '\'' + ','
                           '\'' + caccount[3] + '\'' + ','
                           '\'' + caccount[4] + '\'' + ','
                           '\'' + caccount[5] + '\'' + ','                            
                           "current_date, current_date)")
            db.commit()
        except:
            db.rollback()
    cursor.close()
#删除操作
def caccount_delete(db, caccount):
    cursor = db.cursor()
    try:
        cursor.execute("SET foreign_key_checks = 0")
        cursor.execute("delete from caccount where cacid = " + caccount[1])
        cursor.execute("SET foreign_key_checks = 1")
        db.commit()
    except:
        db.rollback()
        cursor.close()
        return "ERROR"
    cursor.close()
    return "OK"
#更新操作
def caccount_update(db, caccount):
    cursor = db.cursor()
    line = ("cacid", "overdraft", "cbalance")
    try:
        i = 2
        while i < 4:  # 对每一个列的输入都做一次更新
            if caccount[i] == '':
                i = i + 1
                continue
            cursor.execute("update caccount set " + line[i - 1] + " = \'" + caccount[i]
                           + "\' where cacid = \'" + caccount[1] +'\'')
            i = i + 1
        cursor.execute("update caccount set clatestdate=current_date where cacid=\'"
                       + caccount[1] + '\'')
        db.commit()
    except:
        db.rollback()
    cursor.close()




#贷款信息操作
#查询操作
def loan_search(db, loan):
    cursor = db.cursor()

    res = list()

    if loan[1] == '':
        return ''

    if loan[1] == '*':    #查询所有元组
        cursor.execute("select * from loan")
        rowout = cursor.fetchall()
        cursor.execute("select loana from loan")
        tot = cursor.fetchall()
        cursor.execute("select loana-sum(amount) from loan natural join pay group by lid")
        rem = cursor.fetchall()

        i = 0
        while i < len(rowout):
            arow = list(rowout[i])
            if rem[i][0] == tot[i][0]:
                arow.insert(2, "unsent")
            elif rem[i][0] == 0:
                arow.insert(2, "sent")
            else:
                arow.insert(2, "sending, remain = " + str(rem[i][0]))
            res.append(arow)
            i = i + 1
        cursor.close()
        return res

    cursor.execute("select * from loan where lid = \'" + loan[1] + '\'')
    row_cnt = cursor.fetchone()
    row_c = list(row_cnt)
    cursor.execute("select loana from loan where lid = \'" + loan[1] + '\'')
    row_tot = cursor.fetchone()
    cursor.execute("select loana-sum(amount) from loan natural join pay where lid = \'" + loan[1] + "\' group by lid")
    row_rem = cursor.fetchone()
    
    if row_rem[0] == row_tot[0]:
        row_c.insert(2, "unsent")
    elif row_rem[0] == 0:
        row_c.insert(2, "sent")
    else:
        row_c.insert(2, "sending, remain = " + str(row_rem[0]))
    if row_c and row_c not in res:
        res.append(row_c)
    cursor.close()
    return res
#添加操作
def loan_add(db, loan):
    cursor = db.cursor()
    if loan[1]:
        try:
            cursor.execute("insert into loan values( " +
                           '\'' + loan[1] + '\'' + ','
                           '\'' + loan[2] + '\'' + ','
                           '\'' + loan[3] + '\'' + ','
                           '\'' + loan[4] + '\'' + ')')
            db.commit()
        except:
            db.rollback()
    cursor.close()
#删除操作
def loan_delete(db, loan):
    cursor = db.cursor()

    if loan[1]:
        cursor.execute("select loana from loan where lid = \'" + loan[1] + '\'')
        tot = cursor.fetchone()
        cursor.execute("select loana-sum(amount) from loan natural join pay where lid = \'" + loan[1] + "\' group by lid")
        rem = cursor.fetchone()

        if rem[0] == tot[0] or rem[0] == 0:
            try:
                cursor.execute("SET foreign_key_checks = 0")
                cursor.execute("SET SQL_SAFE_UPDATES = 0")
                cursor.execute("delete from loan where lid = " + loan[1])
                cursor.execute("SET foreign_key_checks = 1")
                cursor.execute("SET SQL_SAFE_UPDATES = 1")
                db.commit()
            except:
                db.rollback()
                cursor.close()
                return "ERROR"
        else:
            cursor.close()
            return "SENDING"
    cursor.close()
    return "OK"
#付款操作
def loan_pay(db, loan):
    cursor = db.cursor()

    if loan[1]:
        cursor.execute("select loana from loan where lid = \'" + loan[1] + '\'')
        tot = cursor.fetchone()
        cursor.execute("select loana-sum(amount) from loan natural join pay where lid = \'" + loan[1] + "\' group by lid")
        rem = cursor.fetchone()
        if float(loan[6]) <= rem[0]:
            try:
                cursor.execute("insert into pay values(" +
                               '\'' + loan[1] + '\'' + ','
                               '\'' + loan[5] + '\'' + ','
                               '\'' + loan[6] + "\', current_date)")
                db.commit()
            except:
                db.rollback()
                cursor.close()
                return "ERROR"
        else:
            cursor.close()
            return "TOO MUCH"
    cursor.close()
    return "OK"

#业务统计
#支出资产
def business_paid(db):
    cursor = db.cursor()
    cursor.execute("select city, 'loans pay', paydate, sum(amount) from loan natural "
                   "join pay natural join branch group by brid, paydate having sum(amount) != 0")
    res1 = cursor.fetchall();
    cursor.execute("select city, 'saving balance', sopendate, sum(sbalance) "
                   "from saccount natural join branch group by brid, sopendate")
    res2 = cursor.fetchall();
    cursor.execute("select city, 'check balance', copendate, sum(cbalance) "
                   "from caccount natural join branch group by brid, copendate")
    res3 = cursor.fetchall();

    return res1 + res2 + res3
    cursor.close()
#客户数量
def business_user(db):
    cursor = db.cursor()
    cursor.execute("select city, 'loans pay', count(distinct id) "
                   "from loan natural join pay natural join branch group by brid;")
    res1 = cursor.fetchall();
    cursor.execute("select city, 'saving balance', count(distinct id) "
                   "from saccount natural join branch group by brid;")
    res2 = cursor.fetchall();
    cursor.execute("select city, 'check balance', count(distinct id) "
                   "from caccount natural join branch group by brid;")
    res3 = cursor.fetchall();

    return res1 + res2 + res3
    cursor.close()





def db_close(db):
    if db is not None:
        db.close()

if __name__ == "__main__":
    db = db_login("lyp1234", "1234", "127.0.0.1", "test")

    tabs = db_showtable(db)
    
    db_close(db)