#drop database if exists bank;
#create database bank;
use bank;

SET foreign_key_checks = 0;
drop table if exists bclient;
drop table if exists branch;
drop table if exists saccount;
drop table if exists slimit;
drop table if exists caccount;
drop table if exists climit;
drop table if exists loan;
drop table if exists pay;
drop table if exists llimit;
SET foreign_key_checks = 1;

create table bclient (
id varchar(30) primary key,
name varchar(30),
phone varchar(30),
address varchar(30),
linkname varchar(30),
linkphone varchar(30),
linkemail varchar(30),
link varchar(30)
);

create table branch (
brid varchar(30) primary key,
city varchar(30),
asset varchar(30)
);

create table saccount (
sacid varchar(30) primary key,
rate varchar(30),
curtype varchar(30),
sbalance float not null,
id varchar(30),
brid varchar(30),
constraint sbclient foreign key(id) references bclient(id),
constraint sbranch foreign key(brid) references branch(brid),
sopendate varchar(30),
slatestdate varchar(30)
);

create table slimit (
id varchar(30),
brid varchar(30),
sacid varchar(30),
primary key(id, brid, sacid),
constraint s_bclient foreign key(id) references bclient(id),
constraint s_branch foreign key(brid) references branch(brid),
constraint saccount foreign key(sacid) references saccount(sacid)
);

create table caccount (
cacid varchar(30) primary key,
overdraft varchar(30),
cbalance float not null,
id varchar(30),
brid varchar(30),
constraint cbclient foreign key(id) references bclient(id),
constraint cbranch foreign key(brid) references branch(brid),
copendate varchar(30),
clatestdate varchar(30)
);

create table climit (
id varchar(30),
brid varchar(30),
cacid varchar(30),
primary key(id, brid, cacid),
constraint c_bclient foreign key(id) references bclient(id),
constraint c_branch foreign key(brid) references branch(brid),
constraint caccount foreign key(cacid) references caccount(cacid)
);

create table loan (
lid varchar(30) primary key,
loana float not null,
id varchar(30),
brid varchar(30),
constraint lbclient foreign key(id) references bclient(id),
constraint lbranch foreign key(brid) references branch(brid)
);

create table pay (
lid varchar(30),
pid varchar(30),
primary key(lid, pid),
amount float not null,
paydate date,
constraint ploan foreign key(lid) references loan(lid)
);

create table llimit (
id varchar(30),
brid varchar(30),
lid varchar(30),
primary key(id, brid, lid),
constraint l_bclient foreign key(id) references bclient(id),
constraint l_branch foreign key(brid) references branch(brid),
constraint lloan foreign key(lid) references loan(lid)
);



drop trigger if exists slimi;
drop trigger if exists climi;
drop trigger if exists llimi;
drop trigger if exists plimi;
drop trigger if exists slimd;
drop trigger if exists climd;
drop trigger if exists llimd;
drop trigger if exists plimd;
delimiter zzz
create trigger slimi after insert on saccount for each row
begin
	insert into slimit values(new.id, new.brid, new.sacid);
end zzz
delimiter ;
delimiter zzz
create trigger climi after insert on caccount for each row
begin
	insert into climit values(new.id, new.brid, new.cacid);
end zzz
delimiter ;
delimiter zzz
create trigger llimi after insert on loan for each row
begin
	insert into llimit values(new.id, new.brid, new.lid);
end zzz
delimiter ;
delimiter zzz
create trigger plimi after insert on loan for each row
begin
	insert into pay values(new.lid, '0', 0, current_date);
end zzz
delimiter ;




delimiter zzz
create trigger slimd after delete on saccount for each row
begin
	delete from slimit where sacid = old.sacid;
end zzz
delimiter ;
delimiter zzz
create trigger climd after delete on caccount for each row
begin
	delete from climit where cacid = old.cacid;
end zzz
delimiter ;
delimiter zzz
create trigger llimd after delete on loan for each row
begin
	delete from llimit where lid = old.lid;
end zzz
delimiter ;
delimiter zzz
create trigger plimd after delete on loan for each row
begin
	delete from pay where lid = old.lid;
end zzz
delimiter ;



insert into branch values('1', 'heifei', '5000w');
insert into branch values('2', 'beijing', '5000w');
insert into branch values('3', 'shanghai', '5000w');
insert into branch values('4', 'guangzhou', '5000w');
insert into branch values('5', 'shenzhen', '5000w');

insert into bclient values('1', 'zzc', '18256', 'ustc', 'czz', '12345',
'czz@ustc', 'classmate');
insert into bclient values('2', 'zzc''', '18256', 'ustc', 'czz''', '12345',
'czz@ustc', 'classmate');

insert into saccount values('1', '5%', 'RMB', '100000', '1', '1', 
'2019-3-1', '2019-3-1');
insert into saccount values('2', '5%', 'RMB', '200000', '1', '2', 
'2019-3-1', '2019-3-1');
insert into saccount values('3', '5%', 'RMB', '300000', '1', '3', 
'2019-3-7', '2019-3-7');

insert into caccount values('1', '10w', '100000', '1', '1',
'2019-9-1', '2019-9-1');
insert into caccount values('2', '10w', '200000', '1', '2',
'2019-10-19', '2019-10-19');
insert into caccount values('3', '10w', '300000', '1', '3',
'2019-9-1', '2019-10-19');
insert into caccount values('4', '10w', '400000', '2', '3',
'2019-10-13', '2019-10-19');


insert into loan values('1', '100000', '1', '1');
insert into loan values('2', '100000', '1', '2');
insert into loan values('3', '100000', '1', '3');


insert into pay values('1', '1', '10000',  '2020-11-11');
insert into pay values('1', '2', '10000',  '2020-11-11');
insert into pay values('1', '3', '10000',  '2020-11-21');
insert into pay values('1', '4', '10000',  '2020-12-11');

insert into pay values('2', '1', '10000',  '2020-12-11');
