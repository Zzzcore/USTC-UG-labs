import functools

from flask import Flask, session
from flask import redirect
from flask import request, make_response
from flask import render_template
from flask import url_for

from db import *

# 生成一个app
app = Flask(__name__, instance_relative_config=True)
app.secret_key = 'lab3'

# 对app执行请求页面地址到函数的绑定
@app.route("/", methods=("GET", "POST"))

#登陆管理
@app.route("/login_a", methods=("GET", "POST"))
def login_a():
    """Log in a registered user by adding the user id to the session."""
    if request.method == "POST":
        # 客户端在login_a页面发起的POST请求
        username = request.form["username"]
        password = request.form["password"]
        ipaddr   = "127.0.0.1"  #request.form["ipaddr"]
        database = request.form["database"]

        db = db_login(username, password, ipaddr, database)

        if db == None:
            return render_template("login_fail.html")
        else:
            session['username'] = username
            session['password'] = password
            session['ipaddr'] = ipaddr
            session['database'] = database

            return redirect(url_for('login'))


    else :
        # 客户端GET 请求login_a页面时
        return render_template("login_a.html")

#登陆后功能选择
@app.route("/login", methods=("GET", "POST"))
def login():
    """Log in a registered user by adding the user id to the session."""
    if request.method == "POST":

        if 'client' in request.form:
            return redirect(url_for('table'))

        elif 'saccount' in request.form:
            return redirect(url_for('table_sac'))

        elif 'caccount' in request.form:
            return redirect(url_for('table_cac'))
        
        elif 'loan' in request.form:
            return redirect(url_for('table_loan'))

        elif 'business' in request.form:
            return redirect(url_for('table_bus'))

        elif 'BACK' in request.form:
            return redirect("http://localhost:5000/", code = 302)

    else :
        # 客户端GET 请求login页面时
        return render_template("login.html")

# 请求url为host/table的页面返回结果 客户信息操作页面
@app.route("/table", methods=(["GET", "POST"]))
def table():
    # 出于简单考虑，每次请求都需要连接数据库，可以尝试使用其它context保存数据库连接
    if 'username' in session:
        db = db_login(session['username'], session['password'], 
                        session['ipaddr'], session['database'])
    else:
        return redirect(url_for('login'))


    if request.method == "POST":
        
        client = list()
        client.append("client")
        client.append(request.form["id"])
        client.append(request.form["name"])
        client.append(request.form["phone"])
        client.append(request.form["address"])
        client.append(request.form["linkname"])
        client.append(request.form["linkphone"])
        client.append(request.form["linkemail"])
        client.append(request.form["link"])

        name_list = list(client[2])
        i = 0
        while i < len(name_list):
            if(name_list[i] == "'"):
                name_list.insert(i,"'")
                i = i + 1
            i = i + 1
        client[2] = "".join(name_list)



        if 'clear' in request.form:
            db_close(db)
            return render_template("table.html", rows = '')
        elif 'search' in request.form:
            tabs = client_search(db, client)
            db_close(db)
            return render_template("table.html", rows = tabs)
        elif 'add' in request.form:
            client_add(db, client)
            db_close(db)
            return render_template("table.html", rows = 'OK')
        elif 'delete' in request.form:
            tabs = client_delete(db, client)
            db_close(db)
            return render_template("table.html", rows = tabs)
        elif 'update' in request.form:
            tabs = client_update(db, client)
            db_close(db)
            return render_template("table.html", rows = tabs)
        elif 'BACK' in request.form:
            return redirect(url_for('login'))

    else:
        return render_template("table.html", rows = '')


# 请求url为host/table_sac的页面返回结果 储蓄账户信息操作页面
@app.route("/table_sac", methods=(["GET", "POST"]))
def table_sac():
    # 出于简单考虑，每次请求都需要连接数据库，可以尝试使用其它context保存数据库连接
    if 'username' in session:
        db = db_login(session['username'], session['password'],
                      session['ipaddr'], session['database'])
    else:
        return redirect(url_for('login'))

    if request.method == "POST":

        saccount = list()
        saccount.append("saccount")
        saccount.append(request.form["sacid"])
        saccount.append(request.form["rate"])
        saccount.append(request.form["curtype"])
        saccount.append(request.form["sbalance"])
        saccount.append(request.form["id"])
        saccount.append(request.form["brid"])

        if 'clear' in request.form:
            db_close(db)
            return render_template("table_sac.html", rows='')
        elif 'search' in request.form:
            tabs = saccount_search(db, saccount)
            db_close(db)
            return render_template("table_sac.html", rows=tabs)
        elif 'add' in request.form:
            saccount_add(db, saccount)
            db_close(db)
            return render_template("table_sac.html", rows='OK')
        elif 'delete' in request.form:
            tabs = saccount_delete(db, saccount)
            db_close(db)
            return render_template("table_sac.html", rows=tabs)
        elif 'update' in request.form:
            saccount_update(db, saccount)
            db_close(db)
            return render_template("table_sac.html", rows='OK')
        elif 'BACK' in request.form:
            return redirect(url_for('login'))

    else:
        return render_template("table_sac.html", rows='')



# 请求url为host/table_cac的页面返回结果 支票账户信息操作页面
@app.route("/table_cac", methods=(["GET", "POST"]))
def table_cac():
    # 出于简单考虑，每次请求都需要连接数据库，可以尝试使用其它context保存数据库连接
    if 'username' in session:
        db = db_login(session['username'], session['password'],
                      session['ipaddr'], session['database'])
    else:
        return redirect(url_for('login'))

    if request.method == "POST":

        caccount = list()
        caccount.append("caccount")
        caccount.append(request.form["cacid"])
        caccount.append(request.form["overdraft"])
        caccount.append(request.form["cbalance"])
        caccount.append(request.form["id"])
        caccount.append(request.form["brid"])

        if 'clear' in request.form:
            db_close(db)
            return render_template("table_cac.html", rows='')
        elif 'search' in request.form:
            tabs = caccount_search(db, caccount)
            db_close(db)
            return render_template("table_cac.html", rows=tabs)
        elif 'add' in request.form:
            caccount_add(db, caccount)
            db_close(db)
            return render_template("table_cac.html", rows='OK')
        elif 'delete' in request.form:
            tabs = caccount_delete(db, caccount)
            db_close(db)
            return render_template("table_cac.html", rows=tabs)
        elif 'update' in request.form:
            caccount_update(db, caccount)
            db_close(db)
            return render_template("table_cac.html", rows='OK')
        elif 'BACK' in request.form:
            return redirect(url_for('login'))

    else:
        return render_template("table_cac.html", rows='')


# 请求url为host/table_loan的页面返回结果 贷款信息操作页面
@app.route("/table_loan", methods=(["GET", "POST"]))
def table_loan():
    # 出于简单考虑，每次请求都需要连接数据库，可以尝试使用其它context保存数据库连接
    if 'username' in session:
        db = db_login(session['username'], session['password'],
                      session['ipaddr'], session['database'])
    else:
        return redirect(url_for('login'))

    if request.method == "POST":

        loan = list()
        loan.append("loan")
        loan.append(request.form["lid"])
        loan.append(request.form["loana"])
        loan.append(request.form["id"])
        loan.append(request.form["brid"])
        loan.append(request.form["pid"])
        loan.append(request.form["pay"])

        if 'clear' in request.form:
            db_close(db)
            return render_template("table_loan.html", rows='')
        elif 'search' in request.form:
            tabs = loan_search(db, loan)
            db_close(db)
            return render_template("table_loan.html", rows=tabs)
        elif 'add' in request.form:
            loan_add(db, loan)
            db_close(db)
            return render_template("table_loan.html", rows='OK')
        elif 'delete' in request.form:
            tabs = loan_delete(db, loan)
            db_close(db)
            return render_template("table_loan.html", rows=tabs)
        elif 'payc' in request.form:
            tabs = loan_pay(db, loan)
            db_close(db)
            return render_template("table_loan.html", rows=tabs)
        elif 'BACK' in request.form:
            return redirect(url_for('login'))

    else:
        return render_template("table_loan.html", rows='')




# 请求url为host/table_bus的页面返回结果 业务统计页面
@app.route("/table_bus", methods=(["GET", "POST"]))
def table_bus():
    # 出于简单考虑，每次请求都需要连接数据库，可以尝试使用其它context保存数据库连接
    if 'username' in session:
        db = db_login(session['username'], session['password'],
                      session['ipaddr'], session['database'])
    else:
        return redirect(url_for('login'))

    if request.method == "POST":
        if 'BACK' in request.form:
            return redirect(url_for('login'))
        else:
            tab1s = business_paid(db)
            tab2s = business_user(db)
            return render_template("table_bus.html", row1s=tab1s, row2s=tab2s)

    else:
        return render_template("table_bus.html", row1s='', row2s='')



# 测试URL下返回html page
@app.route("/hello")
def hello():
    return "hello world!"

#返回不存在页面的处理
@app.errorhandler(404)
def not_found(e):
    return render_template("404.html")

if __name__ == "__main__":

    app.run(host = "0.0.0.0", debug=True)