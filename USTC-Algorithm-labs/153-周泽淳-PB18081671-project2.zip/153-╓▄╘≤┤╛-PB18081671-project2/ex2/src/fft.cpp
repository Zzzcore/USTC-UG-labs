#include <stdio.h>
#include <windows.h>
#include <math.h>
#define PI 3.1415926535897

typedef struct complex {
	double real;					//������ 
	double imag;
}complex;

complex add(complex a, complex b) {
	complex c;						//�����ӷ� 
	c.real = a.real + b.real;
	c.imag = a.imag + b.imag;
	return c;
}

complex sub(complex a, complex b) {
	complex c;						//�������� 
	c.real = a.real - b.real;
	c.imag = a.imag - b.imag;
	return c;
}

complex mul(complex a, complex b) {
	complex c;						//�����˷� 
	c.real = a.real * b.real - a.imag * b.imag;
	c.imag = a.imag * b.real + a.real * b.imag;
	return c;
}

complex* recursive_fft(complex* a, int n) {
	int i;							//�ݹ�fft�㷨 
	complex w, wn;
	complex* a0, * a1;
	complex* y0, * y1;
	complex* y;
	if (n == 1) return a;
	w.real = 1;
	w.imag = 0;
	wn.real = cos(2 * PI / n);
	wn.imag = sin(2 * PI / n);
	a0 = new complex[n / 2];
	a1 = new complex[n / 2];
	for (i = 0; i < n; i++) {
		if (i % 2 == 0)
			a0[i / 2] = a[i];
		else
			a1[i / 2] = a[i];
	}
	y0 = recursive_fft(a0, n / 2);
	y1 = recursive_fft(a1, n / 2);
	y = new complex[n];
	for (i = 0; i < n / 2; i++) {
		y[i] = add(y0[i], mul(w, y1[i]));
		y[i + n / 2] = sub(y0[i], mul(w, y1[i]));
		w = mul(w, wn);
	}
	return y;
}

void print_result(FILE* fo, complex a[], int n) {
	fprintf(fo, "n=%dʱ��", n);		//��ӡ�����output 
	for (int i = 0; i < n; i++)
		fprintf(fo, "%-15lf", a[i].real);
	fprintf(fo, "\n");
}

void print_standard(complex a[]) {
	printf("n=8ʱ��\n");				//��ӡn=8ʱ�Ľ�����ڿ� 
	for (int i = 0; i < 8; i++)
		printf("{%lf,%lf}\n", a[i].real, a[i].imag);
}

int main() {
	int n, i, j = 0;
	complex* a, * b;
	FILE* fp, * fo, * fi;
	fp = fopen("../input/2_2_input.txt", "r");
	fo = fopen("../output/result.txt", "w");
	fi = fopen("../output/time.txt", "w");

	while (j < 5) {
		fscanf(fp, "%d", &n);
		a = new complex[n];
		for (i = 0; i < n; i++)
			fscanf(fp, "%lf", &a[i].real);
		for (i = 0; i < n; i++)
			a[i].imag = 0;

		double run_time;						//��ȷ��΢���ʱ 
		_LARGE_INTEGER time_start;
		_LARGE_INTEGER time_over;
		double dqFreq;
		LARGE_INTEGER f;
		QueryPerformanceFrequency(&f);
		dqFreq = (double)f.QuadPart;
		QueryPerformanceCounter(&time_start);

		b = recursive_fft(a, n);

		QueryPerformanceCounter(&time_over);	//��λ�Ǻ��� 
		run_time = 1000 * (time_over.QuadPart - time_start.QuadPart) / dqFreq;

		print_result(fo, b, n);
		fprintf(fi, "����ʱ�䣺%lfms\n", run_time);
		if (j == 0) print_standard(b);

		j++;
		delete[] a; delete[] b;
	}
	fclose(fi);
	fclose(fo);
	fclose(fp);
}
