#include<stdio.h>
#include<windows.h>

void matrix_chain_order(int n, long long p[],long long** m, long long** s) {
	int i,j,k,l;							//�������˶�̬�滮�㷨 
	long long q;
	for (i=1;i<=n;i++)
		m[i][i]=0;
	for (l=2;l<=n;l++){
		for(i=1;i<=n-l+1;i++){
			j=i+l-1;
			m[i][j]= 9223372036854775807;
			for(k=i;k<=j-1;k++){
				q=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];
				if (q<m[i][j]){
					m[i][j]=q;
					s[i][j]=k;
				}
			}
		}
	}
}

void print_optimal_parens(long long **s,int i,int j,FILE *fo){
	if (i==j) fprintf(fo,"A%d",i);			//��ӡ���Ž� 
	else{
		fprintf(fo,"(");
		print_optimal_parens(s,i,s[i][j],fo);
		print_optimal_parens(s,s[i][j]+1,j,fo);
		fprintf(fo,")");
	}
}

void print_standard(long long **m,long long **s){
    int i,j;								//��ӡ�����ʱ��ģ������ά���� 
    printf("m[5][5]:\n");
    for(i=1;i<=5;i++){
        for(j=1;j<=5;j++){
            if(m[i][j]>0) printf("%-15lld ",m[i][j]);
            else printf("                ");
        }
        printf("\n\n");
    }
    printf("ss[5][5]:\n");
    for(i=1;i<=5;i++){
        for(j=1;j<=5;j++){
            if(s[i][j]>0) printf("%-15d ",s[i][j]);
            else printf("                ");
        }
        printf("\n\n");
    }
}

int main() {
	int n, i, k, j = 0;
	long long* p;
	long long** m, ** s;
	FILE* fp,*fo,*fi;
	fp=fopen("../input/2_1_input.txt", "r");
	fo=fopen("../output/result.txt","w");
	fi=fopen("../output/time.txt","w");
	
	while (j < 5) {
		fscanf(fp, "%d", &n);
		p = new long long[n + 1];					//�ڶѿռ�洢m��s��������ά���� 
		for (i = 0; i < n + 1; i++)
			fscanf(fp, "%lld", p + i);
		m = new long long* [n+1];				 
		for (i = 1; i < n+1; i++)
			m[i] = new long long[n+1];
		s = new long long* [n+1];
		for (i = 1; i < n+1; i++)
			s[i] = new long long[n+1];		
		for(i=1;i<=n;i++)
			for(k=1;k<=n;k++)
				m[i][k]=s[i][k]=0;

		double run_time;						//��ȷ��΢���ʱ 
		_LARGE_INTEGER time_start;
		_LARGE_INTEGER time_over;
		double dqFreq;
		LARGE_INTEGER f;
		QueryPerformanceFrequency(&f);
		dqFreq = (double)f.QuadPart;
		QueryPerformanceCounter(&time_start);

		matrix_chain_order(n, p, m, s);

		QueryPerformanceCounter(&time_over);	//��λ�Ǻ��� 
		run_time = 1000 * (time_over.QuadPart - time_start.QuadPart) / dqFreq; 

		if(j>0) fprintf(fo,"\n");
		fprintf(fo,"��С�˷�������%lld\n",m[1][n]);
		print_optimal_parens(s,1,n,fo);
		fprintf(fi,"����ʱ�䣺%lfms\n",run_time);
        if(j==0) print_standard(m,s);

		j++;
		delete [] p; delete [] m; delete [] s;
		p=NULL;m=NULL;s=NULL;
	}
	fclose(fi);
	fclose(fo);
	fclose(fp);
}
