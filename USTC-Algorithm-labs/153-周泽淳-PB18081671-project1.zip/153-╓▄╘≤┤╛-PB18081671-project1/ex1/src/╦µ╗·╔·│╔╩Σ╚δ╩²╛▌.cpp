#include<stdio.h>
#include<stdlib.h> 
#include<time.h> 

#define pow2_18 1024*256
#define pow2_15 1024*32

int main(){
	FILE *fp;
	fp=fopen("../input/input.txt","w");
	srand((unsigned)time(0));
	for(unsigned i=0;i<pow2_18;i++){
    	int n=rand()%(pow2_15)+0;
    	fprintf(fp,"%d\n",n);
	}
	printf("1\n");
	return 0;
}
