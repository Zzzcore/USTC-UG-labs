#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include<time.h> 
using namespace std;

#define red 1
#define black 0

typedef struct rbt {		//������Ľ�� 
	bool color;			//Ϊ1ʱ�Ǻ�ɫ��Ϊ0ʱ�Ǻ�ɫ 
	int key;
	struct rbt* left;
	struct rbt* right;
	struct rbt* p;
}rbt, * prbt;

typedef struct RBT {		//��¼һ�ú������root��nil 
	prbt root;
	prbt nil;
}RBT, * PRBT;

void inorder_tree_walk(PRBT t, prbt x, FILE* fp) {			//�������������ļ� 
	if (x != t->nil) {
		inorder_tree_walk(t, x->left, fp);
		fprintf(fp, "%d ", x->key);
		inorder_tree_walk(t, x->right, fp);
	}
}

void left_rotate(PRBT t, prbt x) {				//�������� 
	if (x->right == t->nil)
		return;
	prbt y;
	y = x->right;
	x->right = y->left;
	if (y->left != t->nil)
		y->left->p = x;
	y->p = x->p;
	if (x->p == t->nil)
		t->root = y;
	else if (x == x->p->left)
		x->p->left = y;
	else x->p->right = y;
	y->left = x;
	x->p = y;
}

void right_rotate(PRBT t, prbt x) {				//�������� 
	if (x->left == t->nil)
		return;
	prbt y;
	y = x->left;
	x->left = y->right;
	if (y->right != t->nil)
		y->right->p = x;
	y->p = x->p;
	if (x->p == t->nil)
		t->root = y;
	else if (x == x->p->left)
		x->p->left = y;
	else x->p->right = y;
	y->right = x;
	x->p = y;
}

prbt tree_minimun(PRBT t,prbt x) {				//�ҵ�x��������С��� 
	while (x->left != t->nil)
		x = x->left;
	return x;
}

void rb_transplant(PRBT t, prbt u, prbt v) {		//�޽Ӳ��� 
	if (u->p == t->nil)
		t->root = v;
	else if (u == u->p->left)
		u->p->left = v;
	else u->p->right = v;
	v->p = u->p;
}

void rb_insert_fixup(PRBT t, prbt z) {			//���������󱣳����ʲ��� 
	prbt y;
	while (z->p->color == red) {
		if (z->p == z->p->p->left) {
			y = z->p->p->right;
			if (y->color == red) {
				z->p->color = black;				//case 1
				y->color = black;					//case 1
				z->p->p->color = red;				//case 1
				z = z->p->p;						//case 1
			}
			else {
				if (z == z->p->right) {
					z = z->p;						//case 2
					left_rotate(t, z);				//case 2
				}
				z->p->color = black;				//case 3
				z->p->p->color = red;				//case 3
				right_rotate(t, z->p->p);			//case 3
			}
		}
		else {
			y = z->p->p->left;
			if (y->color == red) {
				z->p->color = black;				//case 1
				y->color = black;					//case 1
				z->p->p->color = red;				//case 1
				z = z->p->p;						//case 1
			}
			else {
				if (z == z->p->left) {
					z = z->p;						//case 2
					right_rotate(t, z);				//case 2
				}
				z->p->color = black;				//case 3
				z->p->p->color = red;				//case 3
				left_rotate(t, z->p->p);			//case 3
			}
		}
		t->root->color = black;
	}
}

void rb_insert(PRBT t, prbt z) {			//������������ 
	prbt x, y;
	y = t->nil;
	x = t->root;
	while (x != t->nil) {
		y = x;
		if (z->key < x->key)
			x = x->left;
		else x = x->right;
	}
	z->p = y;
	if (y == t->nil)
		t->root = z;
	else if (z->key < y->key)
		y->left = z;
	else y->right = z;
	z->left = t->nil;
	z->right = t->nil;
	z->color = red;
	rb_insert_fixup(t, z);
}

void rb_delete_fixup(PRBT t,prbt x) {			//�����ɾ������ά�����ʲ��� 
	prbt w;
	while (x != t->root && x->color == black) {
		if (x == x->p->left) {
			w = x->p->right;
			if (w->color == red) {
				w->color = black;					//case 1
				x->p->color = red;					//case 1
				left_rotate(t, x->p);				//case 1
				w = x->p->right;					//case 1
			}
			if (w->left->color == black && w->right->color == black) {
				w->color = red;						//case 2
				x = x->p;							//case 2
			}
			else { 
				if (w->right->color == black) {
					w->left->color = black;			//case 3
					w->color = red;					//case 3
					right_rotate(t, w);				//case 3
					w = x->p->right;				//case 3
				}
				w->color = x->p->color;				//case 4
				x->p->color = black;				//case 4
				w->right->color = black;			//case 4
				left_rotate(t, x->p);				//case 4
				x = t->root;						//case 4
			}
		}
		else {
			w = x->p->left;
			if (w->color == red) {
				w->color = black;					//case 1
				x->p->color = red;					//case 1
				right_rotate(t, x->p);				//case 1
				w = x->p->left;						//case 1
			}
			if (w->right->color == black && w->left->color == black) {
				w->color = red;						//case 2
				x = x->p;							//case 2
			}
			else {
				if (w->left->color == black) {
					w->right->color = black;		//case 3
					w->color = red;					//case 3
					left_rotate(t, w);				//case 3
					w = x->p->left;					//case 3
				}	
				w->color = x->p->color;				//case 4
				x->p->color = black;				//case 4
				w->left->color = black;				//case 4
				right_rotate(t, x->p);				//case 4
				x = t->root;						//case 4
			}
		}
	}
	x->color = black;
}

void rb_delete(PRBT t, prbt z) {				//�����ɾ�������� 
	prbt x,y;
	y = z;
	bool y_original_color = y->color;
	if (z->left == t->nil) {
		x = z->right;
		rb_transplant(t, z, z->right);
	}
	else if (z->right == t->nil) {
		x = z->left;
		rb_transplant(t, z, z->left);
	}
	else {
		y = tree_minimun(t, z->right);
		y_original_color = y->color;
		x = y->right;
		if (y->p == z)
			x->p = y;
		else {
			rb_transplant(t, y, y->right);
			y->right = z->right;
			y->right->p = y;
		}
		rb_transplant(t, z, y);
		y->left = z->left;
		y->left->p = y;
		y->color = z->color;
	}
	if (y_original_color == black)
		rb_delete_fixup(t, x);
}




int main() {
	FILE* fp, * fino, * ftime1, * fdel, * ftime2;
	fino = fopen("../output/inorder.txt", "w");
	ftime1 = fopen("../output/time1.txt", "w");
	fdel = fopen("../output/delete_data.txt", "w");
	ftime2 = fopen("../output/time2.txt", "w");
	
	int n = 20, i, j, h;
	int* delete_i = NULL;
	bool *delete_flag = NULL;
	PRBT t = NULL;
	prbt z = NULL;
	prbt* delete_node = NULL;
	
	double run_time;						//��ȷ��΢���ʱ 
	_LARGE_INTEGER time_start;				
	_LARGE_INTEGER time_over;				
	double dqFreq;							
	LARGE_INTEGER f;						
	
	
	for (n = 20; n <= 100; n=n+20) {
	 
		fp = fopen("../input/input.txt", "r");			//��ʼ��t.nil 
		t = (PRBT)malloc(sizeof(RBT));					//�Ȱѵ�һ�����ŵ�������  
		t->nil = (prbt)malloc(sizeof(rbt));
		t->nil->color = black;
		t->nil->left = t->nil->p = t->nil->right = t->nil;
		z = (prbt)malloc(sizeof(rbt));
		fscanf(fp, "%d", &(z->key));
		z->color = black;
		z->left = t->nil;
		z->right = t->nil;
		z->p = t->nil;
		t->root = z;
		
		delete_node = (prbt*)malloc((n / 4) * sizeof(prbt));		//���ѡn/4�������£�����֮��ɾ�� 
		delete_flag = (bool*)malloc(n * sizeof(bool));
		delete_i = (int*)malloc(n * sizeof(int));
		memset(delete_i, -1, n);
		memset(delete_flag, 0, n*sizeof(bool));
		srand((unsigned)time(0));
		for (i = 0; i < n / 4;) {
			h = rand() % (n) + 0;
			for (j = 0; j <= i; j++) {
				if (j == i) {
					delete_i[i] = h;
					i++;
				}
				if (delete_i[j] == h) 
					break;
			}
		}
		for (i = 0; i < (n / 4); i++)
			delete_flag[delete_i[i]] = 1;
		j = 0;
		if (delete_flag[0] == 1) {
			delete_node[j] = z;
			j++;
		}
		
		
		QueryPerformanceFrequency(&f);
		dqFreq=(double)f.QuadPart;
		QueryPerformanceCounter(&time_start);			//����n����㽨������� 
		for (i = 1; i < n; i++) {
			z = (prbt)malloc(sizeof(rbt));
			fscanf(fp, "%d", &(z->key));
			rb_insert(t, z);
			if (delete_flag[i] == 1) {
				delete_node[j] = z;
				j++;
			}
		}	
		QueryPerformanceCounter(&time_over);	//��λ�Ǻ��� 
		run_time=1000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;	
		fprintf(ftime1, "%llfms\n", run_time);
		inorder_tree_walk(t, t->root, fino);
		fprintf(fino, "\n");
		
		
		QueryPerformanceFrequency(&f);
		dqFreq=(double)f.QuadPart;
		QueryPerformanceCounter(&time_start);		//ɾ��֮ǰ���µ������n/4�����	
		for (i = 0; i < (n / 4); i++) 
			rb_delete(t, delete_node[i]);	
		QueryPerformanceCounter(&time_over);	//��λ�Ǻ��� 
		run_time=1000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;			
		fprintf(ftime2, "%llfms\n", run_time);
		fprintf(fdel, "ɾ���Ľ�㣺");
		for(i = 0; i < (n / 4); i++) 
			fprintf(fdel, "%d ", delete_node[i]->key);
		fprintf(fdel, "\nɾ��֮������������");
		inorder_tree_walk(t, t->root, fdel);
		fprintf(fdel, "\n");
		
		
		free(t);
		free(z);
		free(delete_i);
		free(delete_flag);
		free(delete_node);
		fclose(fp);
	}
	fclose(fino);
	fclose(ftime1);
	fclose(fdel);
	fclose(ftime2);
}
