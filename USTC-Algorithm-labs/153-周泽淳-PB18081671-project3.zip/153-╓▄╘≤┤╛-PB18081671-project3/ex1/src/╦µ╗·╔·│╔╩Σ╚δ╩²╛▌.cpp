#include<stdio.h>
#include<stdlib.h> 
#include<time.h> 

int main(){
	int i,j,n,flag=1;
	int a[100]; 
	FILE *fp;
	fp=fopen("../input/input.txt","w");
	for(i=0;i<100;i++)
		a[i]=-1;
	srand((unsigned)time(0));
	for(i=0;i<100;){
    	n=rand()%(100)+0;
    	for(j=0;j<i;j++){
    		if(a[j]==n){
    			flag=0;break;
			}
		}
		if(flag==1){
    		fprintf(fp,"%d\n",n);
			a[i]=n;
			i++;
		}
    	flag=1;
	}
	printf("1\n");
	fclose(fp;)
}
