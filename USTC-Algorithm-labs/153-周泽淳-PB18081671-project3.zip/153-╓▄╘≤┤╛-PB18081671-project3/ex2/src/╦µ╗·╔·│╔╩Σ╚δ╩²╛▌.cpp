#include<stdio.h>
#include<stdlib.h> 
#include<time.h> 

int main(){
	int i,j,n,flag=1;
	int a[15],b[15]; 
	FILE *fp;
	fp=fopen("../input/input.txt","w");
	for(i=0;i<15;i++)
		a[i]=b[i]=-1;
	srand((unsigned)time(0));
	for (i = 0; i < 15;) {
		n = rand() % (25)+0;
		for (j = 0; j <= i; j++) {
			if (j == i) {
				a[i] = n;
				i++;
			}
			if (a[j] == n)
				break;
		}
	}
	for (i = 0; i < 15;) {
		n = rand() % (20)+30;
		for (j = 0; j <= i; j++) {
			if (j == i) {
				b[i] = n;
				i++;
			}
			if (b[j] == n)
				break;
		}
	}
	for (i = 0; i < 15;) {
		n = rand() % (25)+1;
		if(n <= a[i]) continue;
		fprintf(fp,"%d %d\n",a[i],n);
		i++;
	}
	for (i = 0; i < 15;) {
		n = rand() % (20)+31;
		if(n <= b[i]) continue;
		fprintf(fp,"%d %d\n",b[i],n);
		i++;
	}
	
	printf("1\n");
	fclose(fp);
}
