#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include<time.h> 
using namespace std;

#define red 1
#define black 0

typedef struct interval {
	int low;
	int high;
}interval;

typedef struct rbt {		//�������Ĺؼ���key��Ϊinte.low 
	interval inte;
	bool color;			 
	int max;
	struct rbt* left;
	struct rbt* right;
	struct rbt* p;
}rbt, * prbt;

typedef struct RBT {		//��¼һ����������root��nil 
	prbt root;
	prbt nil;
}RBT, * PRBT;

void mantain_max(PRBT t, prbt x) {				//�ڲ����ɾ����ά������������max��Ա 
	if (x != t->nil) {
		mantain_max(t, x->left);
		mantain_max(t, x->right);
		x->max = x->left->max;
		if (x->max < x->right->max)
			x->max = x->right->max;
		if (x->max < x->inte.high)
			x->max = x->inte.high;
	}
}

void inorder_tree_walk(PRBT t, prbt x, FILE* fp) {			//�������������ļ� 
	if (x != t->nil) {
		inorder_tree_walk(t, x->left, fp);
		fprintf(fp, "%d %d %d\n", x->inte.low, x->inte.high, x->max);
		inorder_tree_walk(t, x->right, fp);
	}
}

void left_rotate(PRBT t, prbt x) {				//�������� 
	if (x->right == t->nil)
		return;
	prbt y;
	y = x->right;
	x->right = y->left;
	if (y->left != t->nil)
		y->left->p = x;
	y->p = x->p;
	if (x->p == t->nil)
		t->root = y;
	else if (x == x->p->left)
		x->p->left = y;
	else x->p->right = y;
	y->left = x;
	x->p = y;
}

void right_rotate(PRBT t, prbt x) {				//�������� 
	if (x->left == t->nil)
		return;
	prbt y;
	y = x->left;
	x->left = y->right;
	if (y->right != t->nil)
		y->right->p = x;
	y->p = x->p;
	if (x->p == t->nil)
		t->root = y;
	else if (x == x->p->left)
		x->p->left = y;
	else x->p->right = y;
	y->right = x;
	x->p = y;
}

prbt tree_minimun(PRBT t, prbt x) {				//�ҵ�x��������С��� 
	while (x->left != t->nil)
		x = x->left;
	return x;
}

void rb_transplant(PRBT t, prbt u, prbt v) {		//�޽Ӳ��� 
	if (u->p == t->nil)
		t->root = v;
	else if (u == u->p->left)
		u->p->left = v;
	else u->p->right = v;
	v->p = u->p;
}

void rb_insert_fixup(PRBT t, prbt z) {			//���������󱣳����ʲ��� 
	prbt y;
	while (z->p->color == red) {
		if (z->p == z->p->p->left) {
			y = z->p->p->right;
			if (y->color == red) {
				z->p->color = black;				//case 1
				y->color = black;					//case 1
				z->p->p->color = red;				//case 1
				z = z->p->p;						//case 1
			}
			else {
				if (z == z->p->right) {
					z = z->p;						//case 2
					left_rotate(t, z);				//case 2
				}
				z->p->color = black;				//case 3
				z->p->p->color = red;				//case 3
				right_rotate(t, z->p->p);			//case 3
			}
		}
		else {
			y = z->p->p->left;
			if (y->color == red) {
				z->p->color = black;				//case 1
				y->color = black;					//case 1
				z->p->p->color = red;				//case 1
				z = z->p->p;						//case 1
			}
			else {
				if (z == z->p->left) {
					z = z->p;						//case 2
					right_rotate(t, z);				//case 2
				}
				z->p->color = black;				//case 3
				z->p->p->color = red;				//case 3
				left_rotate(t, z->p->p);			//case 3
			}
		}
		t->root->color = black;
	}
}

void rb_insert(PRBT t, prbt z) {			//������������ 
	prbt x, y;
	y = t->nil;
	x = t->root;
	while (x != t->nil) {
		y = x;
		if (z->inte.low < x->inte.low)
			x = x->left;
		else x = x->right;
	}
	z->p = y;
	if (y == t->nil)
		t->root = z;
	else if (z->inte.low < y->inte.low)
		y->left = z;
	else y->right = z;
	z->left = t->nil;
	z->right = t->nil;
	z->color = red;
	rb_insert_fixup(t, z);
}

void rb_delete_fixup(PRBT t, prbt x) {			//�����ɾ������ά�����ʲ��� 
	prbt w;
	while (x != t->root && x->color == black) {
		if (x == x->p->left) {
			w = x->p->right;
			if (w->color == red) {
				w->color = black;					//case 1
				x->p->color = red;					//case 1
				left_rotate(t, x->p);				//case 1
				w = x->p->right;					//case 1
			}
			if (w->left->color == black && w->right->color == black) {
				w->color = red;						//case 2
				x = x->p;							//case 2
			}
			else {
				if (w->right->color == black) {
					w->left->color = black;			//case 3
					w->color = red;					//case 3
					right_rotate(t, w);				//case 3
					w = x->p->right;				//case 3
				}
				w->color = x->p->color;				//case 4
				x->p->color = black;				//case 4
				w->right->color = black;			//case 4
				left_rotate(t, x->p);				//case 4
				x = t->root;						//case 4
			}
		}
		else {
			w = x->p->left;
			if (w->color == red) {
				w->color = black;					//case 1
				x->p->color = red;					//case 1
				right_rotate(t, x->p);				//case 1
				w = x->p->left;						//case 1
			}
			if (w->right->color == black && w->left->color == black) {
				w->color = red;						//case 2
				x = x->p;							//case 2
			}
			else {
				if (w->left->color == black) {
					w->right->color = black;		//case 3
					w->color = red;					//case 3
					left_rotate(t, w);				//case 3
					w = x->p->left;					//case 3
				}
				w->color = x->p->color;				//case 4
				x->p->color = black;				//case 4
				w->left->color = black;				//case 4
				right_rotate(t, x->p);				//case 4
				x = t->root;						//case 4
			}
		}
	}
	x->color = black;
}

void rb_delete(PRBT t, prbt z) {				//�����ɾ�������� 
	prbt x, y;
	y = z;
	bool y_original_color = y->color;
	if (z->left == t->nil) {
		x = z->right;
		rb_transplant(t, z, z->right);
	}
	else if (z->right == t->nil) {
		x = z->left;
		rb_transplant(t, z, z->left);
	}
	else {
		y = tree_minimun(t, z->right);
		y_original_color = y->color;
		x = y->right;
		if (y->p == z)
			x->p = y;
		else {
			rb_transplant(t, y, y->right);
			y->right = z->right;
			y->right->p = y;
		}
		rb_transplant(t, z, y);
		y->left = z->left;
		y->left->p = y;
		y->color = z->color;
	}
	if (y_original_color == black)
		rb_delete_fixup(t, x);
}


prbt interval_search(PRBT t, interval i){				//�������������� 
	prbt x = t->root;
	while(x != t->nil && (i.high < x->inte.low || x->inte.high < i.low)){
		if(x->left != t->nil && x->left->max >= i.low)
			x=x->left;
		else x = x->right;
	}
	return x;
}



int main() {
	FILE* fp, * fino, * fdel, * fsear;
	fp = fopen("../input/input.txt", "r");
	fino = fopen("../output/inorder.txt", "w");
	fdel = fopen("../output/delete_data.txt", "w");
	fsear = fopen("../output/search.txt", "w");


	int i, j, h;
	int delete_i[3];
	bool delete_flag[30];
	PRBT t = NULL;
	prbt z = NULL;
	prbt delete_node[3];
	interval search[3];


			 
	t = (PRBT)malloc(sizeof(RBT));					//�Ȱѵ�һ�����ŵ�������  
	t->nil = (prbt)malloc(sizeof(rbt));				//��ʼ��t.nil
	t->nil->color = black;
	t->nil->left = t->nil->p = t->nil->right = t->nil;
	t->nil->max = 0;
	z = (prbt)malloc(sizeof(rbt));
	fscanf(fp, "%d", &(z->inte.low));
	fscanf(fp, "%d", &(z->inte.high));
	z->color = black;
	z->left = t->nil;
	z->right = t->nil;
	z->p = t->nil;
	t->root = z;

 
	memset(delete_i, -1, 12);						//�ȼ���Ҫɾ����3�������� 
	memset(delete_flag, 0, 30 * sizeof(bool));
	srand((unsigned)time(0));
	for (i = 0; i < 3;) {
		h = rand() % (30)+0;
		for (j = 0; j <= i; j++) {
			if (j == i) {
				delete_i[i] = h;
				i++;
			}
			if (delete_i[j] == h)
				break;
		}
	}
	for (i = 0; i < 3; i++)
		delete_flag[delete_i[i]] = 1;
	j = 0;
	if (delete_flag[0] == 1) {
		delete_node[j] = z;
		j++;
	}


				
	for (i = 1; i < 30; i++) {					//����30����㽨������� 
		z = (prbt)malloc(sizeof(rbt));
		fscanf(fp, "%d", &(z->inte.low));
		fscanf(fp, "%d", &(z->inte.high));
		rb_insert(t, z);
		if (delete_flag[i] == 1) {
			delete_node[j] = z;
			j++;
		}
	}
	mantain_max(t, t->root);
	inorder_tree_walk(t, t->root, fino);
	fprintf(fino, "\n");


			
	for (i = 0; i < 3; i++)						//ɾ��֮ǰ���µ�3��������		
		rb_delete(t, delete_node[i]);
	mantain_max(t, t->root);
	fprintf(fdel, "ɾ���Ľ�㣺\n");
	for (i = 0; i < 3; i++)
		fprintf(fdel, "%d %d %d\n", delete_node[i]->inte.low, delete_node[i]->inte.high, delete_node[i]->max);
	fprintf(fdel, "ɾ��֮������������\n");
	inorder_tree_walk(t, t->root, fdel);


	prbt x;										//�������3�����䣬һ������[0, 25] 
	h = rand() % (25)+0;
	search[0].low = h;
	while(h <= search[0].low)
		h = rand() % (25)+1;
	search[0].high = h;	
	for(i=1;i<3;i++){
		h = rand() % (20)+30;
		search[i].low = h;
		while(h <= search[i].low)
			h = rand() % (20)+31;
		search[i].high = h;
	}
	for(i=0;i<3;i++){							//�������ɵ�3��������� 
		fprintf(fsear, "���������䣺[%d, %d]\n", search[i].low, search[i].high);
		x = interval_search(t, search[i]);
		if(x != t->nil)
			fprintf(fsear, "���������x=[%d, %d]\n", x->inte.low, x->inte.high);
		else
			fprintf(fsear, "���������NULL\n");
		fprintf(fsear, "\n");
	}
	
	
	free(t);
	free(z);
	fclose(fp);
	fclose(fino);
	fclose(fdel);
	fclose(fsear);
}
