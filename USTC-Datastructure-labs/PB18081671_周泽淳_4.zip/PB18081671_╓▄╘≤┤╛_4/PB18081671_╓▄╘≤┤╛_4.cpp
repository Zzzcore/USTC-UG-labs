#include<stdio.h>
#include<stdlib.h>
typedef struct arcnode{
	int adjvex;
	struct arcnode *nextarc;
}arcnode;
typedef struct vnode{
	int data;
	arcnode *firstarc;
}vnode,adjlist[50];
typedef struct{
	adjlist vertices;
	int vexnum,arcnum;
}algraph;


void creatg(algraph &g){	//��������ߵ������������ͼ 
	int vnum,anum=0,i,va,vb;
	arcnode *p,*s;
	scanf("%d",&vnum);
	g.vexnum=vnum;
	for(i=0;i<vnum;i++)
		g.vertices[i].data=i,g.vertices[i].firstarc=NULL;
	while(1){
		scanf("%d %d",&va,&vb);
		if(va==-1) break;
		anum++;
		
		p=(arcnode*)malloc(sizeof(arcnode));
		p->adjvex=vb;
		p->nextarc=NULL;
		if(g.vertices[va].firstarc==NULL)
			g.vertices[va].firstarc=p;
		else{
			s=g.vertices[va].firstarc;
			while(s->nextarc!=NULL)
				s=s->nextarc;
			s->nextarc=p;
		}
		
		p=(arcnode*)malloc(sizeof(arcnode));
		p->adjvex=va;
		p->nextarc=NULL;
		if(g.vertices[vb].firstarc==NULL)
			g.vertices[vb].firstarc=p;
		else{
			s=g.vertices[vb].firstarc;
			while(s->nextarc!=NULL)
				s=s->nextarc;
			s->nextarc=p;
		}
	}
	g.arcnum=anum;
}


int visit[50],low[50],count;	//��DFS��ؽڵ� 
int articul[50]={0},j=0;
void dfsarticul(algraph g,int v){
	int min,w;
	arcnode *p;
	visit[v]=min=count++;
	for(p=g.vertices[v].firstarc;p!=NULL;p=p->nextarc){
		w=p->adjvex;
		if(visit[w]==0){
			dfsarticul(g,w);
			if(low[w]<min) min=low[w];
			if(low[w]>=visit[v]) articul[j]=v,j++;
		}
		else if(visit[w]<min) min=visit[w];
	}
	low[v]=min;                                                                                           
}
void findarticul(algraph g){
	int i,v;
	arcnode *p;
	count=1;
	visit[0]=1;
	for(i=1;i<g.vexnum;i++) visit[i]=0;
	p=g.vertices[0].firstarc;
	v=p->adjvex;
	dfsarticul(g,v);
	if(count<g.vexnum){
		articul[j]=0,j++;
		while(p->nextarc){
			p=p->nextarc;
			v=p->adjvex;
			if(visit[v]==0) dfsarticul(g,v);
		}
	}
}


void sortarticul(int aa[],int jjj){		//��������Ĺؽڵ㲢������� 
	int sort[jjj],mid;
	int ii,jj;
	for(ii=0;ii<jjj;ii++) sort[ii]=aa[ii];
	for(ii=1;ii<jjj;ii++)
		for(jj=ii;jj>0;jj--)
			if(sort[jj]<sort[jj-1]){
				mid=sort[jj];
				sort[jj]=sort[jj-1];
				sort[jj-1]=mid;
			}
	for(ii=1;ii<jjj;ii++)
		if(sort[ii]!=sort[ii+1]||ii==jjj-1) printf("%d ",sort[ii]);
	printf("\n");
}


typedef struct path{		//��0�㵽����������·�������� 
	int data;
	struct path *next;
}path,*ppath;
void shortest(algraph g){
	int d[g.vexnum];
	int final[g.vexnum];
	ppath prear[g.vexnum];
	ppath phead[g.vexnum];
	ppath pz,pa,paa;
	int i,k,min;
	int v,w;
	arcnode *p;
	p=g.vertices[0].firstarc;
	for(i=0;i<g.vexnum;i++) phead[i]=NULL;
	for(i=0;i<g.vexnum;i++){
		d[i]=999;
		final[i]=0;
	}
	final[0]=1;
	d[0]=0;
	while(p){ 
		d[p->adjvex]=1;
		p=p->nextarc;
	}
	for(i=1;i<g.vexnum;i++){
		min=999;
		for(w=0;w<g.vexnum;w++)
			if(!final[w])
				if(d[w]<min) v=w,min=d[w];
		final[v]=1;
			if(phead[v]==NULL)
				phead[v]=prear[v],
				phead[v]=(ppath)malloc(sizeof(path)),
				phead[v]->data=v,phead[v]->next=NULL;
			else
				prear[v]->next=(ppath)malloc(sizeof(path)),
				prear[v]->next->data=v,
				prear[v]->next->next=NULL;
		p=g.vertices[v].firstarc;
		while(p){
			if(!final[p->adjvex]&&min<d[p->adjvex]-1){
				d[p->adjvex]=min+1;
				paa=phead[v];
				while(paa){
					pa=(ppath)malloc(sizeof(path));
					pa->data=paa->data;
					if(phead[p->adjvex]==NULL)
						phead[p->adjvex]=pa,prear[p->adjvex]=pa;
					prear[p->adjvex]->next=pa;
					prear[p->adjvex]=prear[p->adjvex]->next;
					paa=paa->next;
				}
			}
			p=p->nextarc;
		}
	}
	for(i=1;i<g.vexnum;i++){
		printf("%d 0",d[i]);
		pz=phead[i];
		while(pz){
			printf("->%d",pz->data);
			pz=pz->next;
		}
		printf("\n");
	}
} 


int main(){
	algraph g;
	creatg(g);
	printf("\n");
	findarticul(g);
	sortarticul(articul,j);
	shortest(g);
}
