#include<stdio.h>
#include<stdlib.h>
typedef struct btree{
	char data[2];
	struct btree *lc,*rc;
}btree,*pbtree;

int i=0;
char ch[100];

void creat(pbtree &T){	//������������� 
	if(ch[i]==' ') i++;
	if(ch[i]!=0){
		T=(pbtree)malloc(sizeof(btree));
		T->data[0]=ch[i],i++;
		if(ch[i]!=' ') T->data[1]=ch[i],i++;
		else T->data[1]=' ';
		if(ch[i-1]>='0'&&ch[i-1]<='9'){
			T->lc=NULL;
			T->rc=NULL;
			return;
		}
		else{
			creat(T->lc);
			creat(T->rc);
		}
	}
	else return;
}

void inordertraverse(btree *pR){	//������������ϲ���������� 
	if(pR==NULL) return;
	if((pR->data[0]=='*'||pR->data[0]=='/')&&(pR->lc->data[0]=='+'||pR->lc->data[0]=='*'||pR->lc->data[0]=='-'||pR->lc->data[0]=='/')) printf("(");
	inordertraverse(pR->lc);
	if((pR->data[0]=='*'||pR->data[0]=='/')&&(pR->lc->data[0]=='+'||pR->lc->data[0]=='-'||pR->lc->data[0]=='*'||pR->lc->data[0]=='/')) printf(")");
	printf("%c",pR->data[0]);
	printf("%c ",pR->data[1]);
	if((pR->data[0]=='*'||pR->data[0]=='/')&&(pR->rc->data[0]=='+'||pR->rc->data[0]=='-'||pR->rc->data[0]=='*'||pR->rc->data[0]=='/')) printf("(");
	inordertraverse(pR->rc);
	if((pR->data[0]=='*'||pR->data[0]=='/')&&(pR->rc->data[0]=='+'||pR->rc->data[0]=='-'||pR->rc->data[0]=='*'||pR->rc->data[0]=='/')) printf(")");
}

void value(pbtree T){	//��ֵ 
	int r=0;
	while(ch[r]!=0) r++;r--;
	char num[10][2];
	char ope;
	int j,k=0,l=0;
	int x,y,sum=0,flag=0;
	for(j=r;j>=0;){
		if(ch[j]==' ') j--;
		if(ch[j]>='0'&&ch[j]<='9'){
			num[k][1]=ch[j],j--;
			if(ch[j]>='0'&&ch[j]<='9') num[k][0]=ch[j],j--;
			else num[k][0]='0';k++;
		}
		else ope=ch[j],j--,l++;
		if(k>=3) flag=1;
		if(l>0){
			if(sum==0) sum=(num[k-1][0]-48)*10+(num[k-1][1]-48),k--;
			x=(num[k-1][0]-48)*10+(num[k-1][1]-48);
			k--;
			if(ope=='+') sum=sum+x;
			if(ope=='-'&&flag==1) sum=sum-x;
			if(ope=='-'&&flag!=1) sum=x-sum;
			if(ope=='*') sum=sum*x;
			if(ope=='/'&&sum/x!=0) sum=sum/x;
			else if(ope=='/') sum=x/sum;
			l=0;
		}
	}
	printf("%d",sum);
}

void postordertraverse(btree *pR){	//������� 
	if(pR==NULL) return;
	postordertraverse(pR->lc);
	postordertraverse(pR->rc);
	printf("%c",pR->data[0]);
	printf("%c ",pR->data[1]);
}

int main(){
	gets(ch);
	pbtree T;
	creat(T);
	inordertraverse(T);
	printf("\n");
	postordertraverse(T);
	printf("\n");
	value(T);
}
